from ._model import SOLO

__all__ = ["SOLO"]
