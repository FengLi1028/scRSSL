import scanpy as sc
import scvi
import numpy as np
import pandas as pd
from sklearn.metrics import f1_score
import time
import matplotlib.pyplot as plt
import seaborn as sns

adata = sc.read('MF_train.h5ad')
# scvi.data.poisson_gene_selection(adata, n_top_genes=10)
# adata = adata[:, adata.var.highly_variable]
# print(adata)
start = time.time()

adata = adata.copy()
scvi.data.setup_anndata(adata, labels_key="train_test1")
vae = scvi.model.SCANVI(adata, "Unknown", n_latent=100, n_layers=1, n_hidden=128)

# train model
vae.train(max_epochs=20, use_gpu=True, batch_size=2000)

# 得到潜在空间的值
# latent = vae.get_latent_representation()

# 得到预测值
pre = vae.predict()
end = time.time()
# recon = vae.get_reconstruction_error()

# fig, ax = plt.subplots(figsize=(6, 6),facecolor='w')
# matrix = vae.get_feature_correlation_matrix()
# sns.heatmap(matrix.corr(),annot=True, vmax=1, square=True, cmap="Blues", fmt='.2g')
# plt.title('相关性热力图')
# plt.show()

# plt.subplots(figsize=(4,4),facecolor='w')# 设置画布大小，分辨率，和底色
# fig=sns.heatmap(matrix.corr(),annot=True, vmax=1, square=True, cmap="Blues", fmt='.2g')#annot为热力图上显示数据；fmt='.2g'为数据保留两位有效数字,square呈现正方形，vmax最大值为1
# plt.show()

# print("predict", np.unique(pre, return_counts=True))
# pre = pd.DataFrame(pre)
# la = pd.DataFrame(latent)
# pre.to_csv('Predict_Resnet_wB.csv', index=None)
# la.to_csv('Latent_wB.csv', index=None)

# train_test1
# true = adata.obs['cell_type'][2209:].values
# pr = pre[2209:]

# train_test2
# true = adata.obs['cell_type'][0:2209].values
# pr = pre[0:2209]

# tra-dataset
t = pd.read_csv('MF_ind.csv', names=['mask'])
ind = list(t.values.reshape(t.values.shape[0], ))
true = adata.obs['cell_type'][ind].values
pr = pre[ind]

f = f1_score(true, pr, average='micro')
print('f1-score:',f)
print('Time:',end-start)
pre = pd.DataFrame(pre)
pre.to_csv('MF_pre.csv')
