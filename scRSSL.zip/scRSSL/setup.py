#!/usr/bin/env python

# This is a shim to hopefully allow Github to detect the package, build is done with poetry

# import setuptools
#
import scanpy as sc
import scvi
import numpy as np
import pandas as pd
from sklearn.metrics import f1_score
import torch
import random

if __name__ == "__main__":

    ite = 1
    score = []
    # result = np.ones([2839,1])
    recon = []
    for i in range(ite):
        print('123')
        adata = sc.read('imblance_mask.h5ad')
        scvi.data.setup_anndata(adata, labels_key="mask")
        vae = scvi.model.SCANVI(adata, "Unknown", n_latent=100, n_layers=1, n_hidden=128)

        # train model
        vae.train(max_epochs=i+1, use_gpu=True)

        # 得到潜在空间的值
        # latent = vae.get_latent_representation()

        # 得到预测值
        pre = vae.predict()
        re = vae.get_reconstruction_error()
        # pre = pd.DataFrame(pre)

        # train_test1
        # true = adata.obs['cell_type'][2209:].values
        # pr = pre[2209:]

        # train_test2
        # true = adata.obs['cell_type'][0:2209].values
        # pr = pre[0:2209]

        # tra-dataset
        t = pd.read_csv('imblance_ind_mask.csv', names=['mask'])
        ind = list(t.values.reshape(t.values.shape[0], ))
        true = adata.obs['cellType'][ind].values
        pr = pre[ind]

        # result = np.c_[result, pr]
        f = f1_score(true, pr, average='micro')
        print(f)
        score.append(f)
        recon.append(re)
    score = np.array(score)
    score = pd.DataFrame(score)
    score.to_csv('f1-score.csv', index=None, header=None)

    recon = np.array(recon)
    recon = pd.DataFrame(recon)
    recon.to_csv('recon_error.csv', index=None, header=None)

    # result = pd.DataFrame(result).T
    # result.to_csv('pre_result.csv', index=None, header=None)
    print('End')
